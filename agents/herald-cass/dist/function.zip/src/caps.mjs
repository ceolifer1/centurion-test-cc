// SPEC-D caps as config-as-code (caps.json) + the America/Chicago active-hours
// and window helpers Cass plans against. Cass never reserves counters (that is
// Piper/Gia at act time via the DB RPC); it only needs the SAME cap numbers and
// the SAME active-hours gate so a plan can never propose a slot Vera would later
// hard-stop. Duplicated from the Piper enforcement copy on purpose (SEC-3).
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

export const CAPS = JSON.parse(readFileSync(join(dirname(fileURLToPath(import.meta.url)), 'caps.json'), 'utf8'));
export const CAPS_VERSION = CAPS.version;

// --- America/Chicago calendar helpers (SPEC-D windows are all CT) -------------
export function ctParts(date) {
  const fmt = new Intl.DateTimeFormat('en-US', {
    timeZone: CAPS.global.active_hours.timezone, weekday: 'short',
    year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false,
  });
  const p = Object.fromEntries(fmt.formatToParts(date).map((x) => [x.type, x.value]));
  let hour = parseInt(p.hour, 10); if (hour === 24) hour = 0;
  return { weekday: p.weekday, y: +p.year, m: +p.month, d: +p.day, hour, minute: +p.minute };
}
export function isoWeekKey(y, m, d) {
  const dt = new Date(Date.UTC(y, m - 1, d));
  const day = dt.getUTCDay() || 7;
  dt.setUTCDate(dt.getUTCDate() + 4 - day);
  const yearStart = new Date(Date.UTC(dt.getUTCFullYear(), 0, 1));
  const week = Math.ceil(((dt - yearStart) / 86400000 + 1) / 7);
  return `${dt.getUTCFullYear()}-W${String(week).padStart(2, '0')}`;
}
const hhmmToMin = (s) => { const [h, mn] = s.split(':').map(Number); return h * 60 + mn; };

// active-hours gate (SPEC-D section 1). actionClass matters on Saturday (posts only).
export function activeHours(date, actionClass) {
  const ct = ctParts(date);
  const ah = CAPS.global.active_hours;
  const mins = ct.hour * 60 + ct.minute;
  if (ct.weekday === 'Sun') return { allowed: false, reason: 'active_hours:sunday' };
  if (ct.weekday === 'Sat') {
    if (ah.saturday.posts_only && actionClass !== 'post') return { allowed: false, reason: 'active_hours:sat_posts_only' };
    if (mins < hhmmToMin(ah.saturday.start) || mins > hhmmToMin(ah.saturday.end)) return { allowed: false, reason: 'active_hours:sat_window' };
    return { allowed: true };
  }
  if (mins < hhmmToMin(ah.weekday.start) || mins > hhmmToMin(ah.weekday.end)) return { allowed: false, reason: 'active_hours:weekday_window' };
  return { allowed: true };
}

// The day/week/burst windows (with caps) for a (platform, actionClass) at a time.
export function windowsFor(platform, actionClass, date) {
  const capDef = CAPS.platforms?.[platform]?.[actionClass];
  if (!capDef) return { capDef: null, windows: [] };
  const ct = ctParts(date);
  const dayKey = `${ct.y}-${String(ct.m).padStart(2, '0')}-${String(ct.d).padStart(2, '0')}`;
  const bucket = Math.floor(ct.minute / CAPS.global.burst.window_minutes) * CAPS.global.burst.window_minutes;
  const windows = [];
  if (capDef.day != null) windows.push({ type: 'day', key: dayKey, cap: capDef.day });
  if (capDef.week != null) windows.push({ type: 'week', key: isoWeekKey(ct.y, ct.m, ct.d), cap: capDef.week });
  windows.push({ type: 'burst', key: `${dayKey}T${String(ct.hour).padStart(2, '0')}:${String(bucket).padStart(2, '0')}`, cap: CAPS.global.burst.max });
  return { capDef, windows };
}

// The per-action cap def (for the planner's target math). Returns { day?, week?, disabled? } or null.
export function capDefFor(platform, actionClass) {
  return CAPS.platforms?.[platform]?.[actionClass] || null;
}
